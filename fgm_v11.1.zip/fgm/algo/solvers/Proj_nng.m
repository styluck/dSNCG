function F = Proj_nng(X)
F = max(X,0);