function AU = Atmap(X,U)

AU = 2*X*U;
